# -*- coding: utf-8 -*-
"""
@author: Shuai Instance 6-3-1-8
"""
import xlrd
import time
import networkx as nx
import numpy as np
import math
import random
import copy
import matplotlib.pyplot as plt
import openpyxl
#node
g_node_list = []
g_unloading_node_list = []
g_pickup_node_list = []
g_schedule_node_list = []
g_delivery_node_list = []
#link
g_link_list = []
g_pickup_link_list = []
g_schedule_link_list = []
g_delivery_link_list = []
g_link_list_graph = []
#agent
g_agent_list = []
g_pickup_agent_list = []
g_schedule_agent_list = []
g_delivery_agent_list = []
#node
g_number_of_nodes = 0
g_number_of_unloading_nodes = 0
g_number_of_pickup_nodes = 0
g_number_of_schedule_nodes = 0
g_number_of_delivery_nodes = 0
#link
g_number_of_links = 0
g_number_of_pickup_links = 0
g_number_of_schedule_links = 0
g_number_of_delivery_links = 0
#agent
g_number_of_agents = 0
g_number_of_pickup_agents = 0
g_number_of_schedule_agents = 0
g_number_of_delivery_agents = 0

time_interval = 1 #Unit time interval
T = 91 * time_interval #Total time of the experiment
Time = 91
t_stamp = 1 * 10 *time_interval #Delivery period
service_time = 1 * time_interval #service time of demand node and delivery node
transfer_time = 1 * time_interval
scheduled_vehicle_speed = 1/time_interval 
logistics_vehicle_speed = 1/time_interval
fixed_logistics_vehicle_cost = 2
fixed_scheduled_freight_cost = 3
each_penalty_cost = 1
traffic_logistics_vehicle_cost = 1  #/km
traffic_scheduled_freight_cost = 1 #/km
epochs = 1 #number of iterations
pu = 1  #number of optimization
phi = 0.96 #attenuation frequency
destination_number = 4

class Node:
    def __init__(self):
        self.node_id = 0
        self.link_type = 0
        self.node_type = 0
        self.start_time = 0
        self.end_time = 0        
        self.ingoing_node_list = []
        self.ingoing_link_list = []
        self.outgoing_node_list = []
        self.outgoing_link_list = []
        self.demand_of_unloading_node = []
        self.conflict_node_list = []
class Link:
    def __init__(self):
        self.link_id = 0
        self.from_node_id = 0
        self.to_node_id = 0
        self.network_type = 0
        self.link_type = 0
        self.link_travel_time = 0
        self.cost = 0
        self.start_time = 0
        self.end_time = 0
        self.length = 0
class Agent:
    def __init__(self):
        self.agent_id = 0
        self.from_node_id = 0
        self.to_node_id = 0
        self.departure_time = 0
        self.arrival_time = 0
        self.initial_state = []
        self.final_state = []
        self.cap = 0
        self.available_node_list = []
        self.available_link_list = []
        self.fixed_cost = 0
        self.type = 0
        self.number = 0
        self.node_sequence = []
        self.time_sequence = []
        self.link_sequence = []
        self.commodity_sequence = []       
class Model():
    def __init__(self):        
        self.model_period = 0        
        self.demand_dict = {}        
        self.demand_id_list = []
        self.pickup_depot = []
        self.origin = []
        self.delivery_dict = {}        
        self.delivery_id_list = []
        self.destination = []                
        self.delivery_depot = []                
        self.pickup_distance_matrix = {}
        self.delivery_distance_matrix = {}
        self.maximum_pickup_time = 10
        self.maximum_delivery_time = 10
        self.logistics_vehicle_cap= 6
        self.scheduled_vehicle_cap = 0
        self.scheduled_freight_cap = 20
        self.scheduled_start_time = []
        self.best_sol = None
        self.rand_d_min = 0
        self.rand_d_max = 0                 
        self.worst_d_max= 0
        self.worst_d_min= 0                
        self.shaw_distance_index = 0 
        self.shaw_time_index = 0 
        self.shaw_demand_index = 0
        self.removal_ratio = 0
        self.removal_route = 0
        self.regret_n = 0
        self.d_weight = np.ones(4) * 1
        self.d_select = np.zeros(4)
        self.d_score = np.zeros(4)
        self.d_history_select = np.zeros(4)
        self.d_history_score = np.zeros(4)
        self.r_weight = np.ones(2)*1
        self.r_select = np.zeros(2)
        self.r_score = np.zeros(2)
        self.r_history_select = np.zeros(2)
        self.r_history_score = np.zeros(2)
        self.rho = 0
        self.r1 = []
        self.r2 = []
        self.r3 = []        
class Solution():
    def __init__(self):        
        self.solution_period = 0
        self.node_id_list = []
        self.obj = 0
        self.stage_obj = 0
        self.pickup_obj = 0
        self.scheduled_obj = 0 
        self.freight_obj = 0        
        self.delivery_obj = 0        
        self.pickup_routes = None
        self.pickup_time = None 
        self.scheduled_routes = None
        self.scheduled_time = None
        self.delivery_routes = None
        self.delivery_time = None
        self.tran_pickup_obj = 0
        self.fixed_pickup_obj = 0
        self.tran_delivery_obj = 0
        self.fixed_delivery_obj = 0 
        self.tran_scheduled_obj = 0
        self.fixed_scheduled_obj = 0
        self.tran_freight_obj = 0
        self.fixed_freight_obj = 0        
        
def g_read_input_data():   
    #initialization
    global g_number_of_nodes,g_number_of_unloading_nodes,g_number_of_pickup_nodes,g_number_of_schedule_nodes,g_number_of_delivery_nodes,g_number_of_demand_nodes     
    global g_number_of_links,g_number_of_pickup_links,g_number_of_schedule_links,g_number_of_delivery_links       
    global g_number_of_agents,g_number_of_schedule_agents,g_number_of_pickup_agents,g_number_of_delivery_agents    
    # read node
    file = xlrd.open_workbook("input_node.xls") # open file
    sheet = file.sheet_by_index(0) # open sheet
    node = Node()
    node.node_id = 0
    g_node_list.append(node)
    g_unloading_node_list.append(node)
    g_pickup_node_list.append(node)
    g_schedule_node_list.append(node)
    g_delivery_node_list.append(node)        

    g_number_of_nodes += 1  
    g_number_of_unloading_nodes += 1
    g_number_of_pickup_nodes += 1    
    g_number_of_schedule_nodes += 1
    g_number_of_delivery_nodes += 1    
    for row in range(1, sheet.nrows):
        try:
            node = Node()
            node.node_id = int(sheet.cell_value(row, 0))
            node.link_type = int(sheet.cell_value(row, 1))
            node.node_type = int(sheet.cell_value(row, 2))            
            demand_of_unloading_node_origin = str(sheet.cell_value(row, 3))
            demand_of_unloading_node = demand_of_unloading_node_origin.strip().split(';')
            node.demand_of_unloading_node = [int (demand) for demand in demand_of_unloading_node]  
            node.start_time = int(sheet.cell_value(row, 4))
            node.end_time = int(sheet.cell_value(row, 5))                         
            g_node_list.append(node)            
            if (node.node_type < 0):
                g_unloading_node_list.append(node)
                g_number_of_unloading_nodes += 1                
            if (node.link_type == 1 or node.link_type == 4):
                g_pickup_node_list.append(node)
                g_number_of_pickup_nodes += 1
            if (node.link_type == 2 or node.link_type == 4 or node.link_type == 5):
                g_schedule_node_list.append(node)
                g_number_of_schedule_nodes += 1                
            if (node.link_type == 3 or node.link_type == 5):
                g_delivery_node_list.append(node)
                g_number_of_delivery_nodes += 1                                              
            g_number_of_nodes += 1
            print('reading {} nodes..'.format(g_number_of_nodes))
        except:
            print('Read error. Check your input node file')
    print('nodes_number:{}'.format(g_number_of_nodes))         
    # read links
    file = xlrd.open_workbook("input_link.xls") # open file
    sheet = file.sheet_by_index(0) # open sheet
    link = Link()
    link.link_id = 0
    g_link_list.append(link)
    g_pickup_link_list.append(link)
    g_schedule_link_list.append(link)
    g_delivery_link_list.append(link)            

    g_number_of_links += 1
    g_number_of_pickup_links += 1    
    g_number_of_schedule_links += 1
    g_number_of_delivery_links += 1     
    for row in range(1, sheet.nrows):
        try:
            link = Link()
            link.link_id = int(sheet.cell_value(row, 0))
            link.from_node_id = int(sheet.cell_value(row, 1))
            link.to_node_id = int(sheet.cell_value(row, 2))
            link.network_type = int(sheet.cell_value(row, 3))
            link.link_type = int(sheet.cell_value(row, 4))            
            link.link_travel_time = int(sheet.cell_value(row, 5))
            link.cost = float(sheet.cell_value(row, 6))
            link.start_time = int(sheet.cell_value(row, 7))
            link.end_time = int(sheet.cell_value(row, 8))             
            link.length = int(sheet.cell_value(row, 5))            
            g_link_list_graph.append((link.from_node_id, link.to_node_id, link.length)) 
            g_link_list.append(link)
            if (link.network_type == 1):
                g_pickup_link_list.append(link)
                g_number_of_pickup_links += 1                            
            if (link.network_type == 2):            
                g_schedule_link_list.append(link)
                g_number_of_schedule_links += 1
            if (link.network_type == 3):
                g_delivery_link_list.append(link)
                g_number_of_delivery_links += 1                                                 
            g_number_of_links += 1
            print('reading {} links..'.format(g_number_of_links))
        except:
            print('Read error. Check your input link file')
    print('links_number:{}'.format(g_number_of_links))  
    # read agents
    file = xlrd.open_workbook("input_agent_case.xls") # open file
    sheet = file.sheet_by_index(0) # open sheet
    agent = Agent()
    agent.agent_id = 0
    g_agent_list.append(agent)
    g_schedule_agent_list.append(agent)
    g_pickup_agent_list.append(agent)
    g_delivery_agent_list.append(agent)    
    
    g_number_of_agents += 1
    g_number_of_schedule_agents += 1
    g_number_of_pickup_agents += 1
    g_number_of_delivery_agents += 1        
    for row in range(1, sheet.nrows):
        try:
            agent = Agent()
            agent.agent_id = int(sheet.cell_value(row, 0))
            agent.from_node_id = int(sheet.cell_value(row, 1))
            agent.to_node_id = int(sheet.cell_value(row, 2))
            agent.departure_time = int(sheet.cell_value(row, 3))
            agent.arrival_time = int(sheet.cell_value(row, 4))            
            initial_state_origin = str(sheet.cell_value(row, 5))
            initial_state = initial_state_origin.strip().split(';')
            agent.initial_state = [int (state) for state in initial_state]
            final_state_origin = str(sheet.cell_value(row, 6))
            final_state = final_state_origin.strip().split(';')
            agent.final_state = [int (state) for state in final_state]
            agent.cap = int(sheet.cell_value(row, 7))            
            available_node_list_0 = str(sheet.cell_value(row, 8))
            available_node_list_1 = available_node_list_0.strip().split(';')
            agent.available_node_list = [int (node) for node in available_node_list_1]              
            available_link_list_0 = str(sheet.cell_value(row, 9))
            available_link_list_1 = available_link_list_0.strip().split(';')
            agent.available_link_list = [int (node) for node in available_link_list_1]            
            agent.fixed_cost = int(sheet.cell_value(row, 10))
            agent.type = int(sheet.cell_value(row, 11)) 
            agent.number = int(sheet.cell_value(row, 12))                                       
            g_agent_list.append(agent)                           
            if (agent.type == 2):
                g_schedule_agent_list.append(agent)
                g_number_of_schedule_agents += 1
            if (agent.type == 1):
                g_pickup_agent_list.append(agent)
                g_number_of_pickup_agents += 1
            if (agent.type == 3):
                g_delivery_agent_list.append(agent)
                g_number_of_delivery_agents += 1                                                 
            g_number_of_agents += 1
            print('reading {} agents..'.format(g_number_of_agents))
        except:
            print('Read. Check your input agent file')
    print('agent_number:{}'.format(g_number_of_agents))           

def g_generate_in_out_going_link():   
    # record ingoing and outgoing nodes and links for each node       
    for l in range(1, g_number_of_links):
        link_id = g_link_list[l].link_id
        from_node_id = g_link_list[l].from_node_id
        to_node_id = g_link_list[l].to_node_id     
        g_node_list[to_node_id].ingoing_link_list.append(link_id)
        g_node_list[to_node_id].ingoing_node_list.append(from_node_id)
        g_node_list[from_node_id].outgoing_link_list.append(link_id)
        g_node_list[from_node_id].outgoing_node_list.append(to_node_id)
        
def g_generate_all_distance():
    global g_number_of_nodes,g_number_of_links,g_node_list,g_link_list
    global node_dis,a,shortest_distance,shortest_Ld,shortest_d_d,shortest_path,shortest_dp
    node_dis = [] 
    for i in range(1, g_number_of_nodes+1):
        node_dis.append([0]*(g_number_of_nodes))    
    #Initialization
    for i in range(1, g_number_of_nodes):
        for j in range(1, g_number_of_nodes):
            if i == j:
                node_dis[i][j] = 0
            elif (g_node_list[j].node_id in g_node_list[i].outgoing_node_list):
                for l in range(1, g_number_of_links):
                    if g_node_list[i].node_id == g_link_list[l].from_node_id and g_node_list[j].node_id == g_link_list[l].to_node_id: 
                        node_dis[i][j] = g_link_list[l].length
            else:
                node_dis[i][j] = 0                
    a = np.array(node_dis)
    G=nx.Graph(a)
    shortest_distance=nx.shortest_path_length(G,weight='weight')
    shortest_Ld = dict(shortest_distance)
    m,n=a.shape
    shortest_d_d=np.zeros((m,n))
    for i in range(m):
        for j in range(n):
            if j in shortest_Ld[i]:
                shortest_d_d[i,j] = shortest_Ld[i][j]                
    shortest_path=nx.shortest_path(G, weight='weight')  
    shortest_dp=dict(shortest_path)                
    return()
def g_generate_period_demand():
    global g_period_demand_list,g_period_delivery_list
    global stage_demand_total_number,stage_destination_total_number,each_stage_destination_total_number 

    stage_demand_total_number = []
    stage_destination_total_number = [0] * destination_number   
    each_stage_destination_total_number = []
    g_pickup_demand_node_list = []
    g_number_of_pickup_demand_nodes = 0    
    g_number_of_pickup_demand_nodes += 1    
    #period_demand
    g_period_demand_list = {}
    for t in range(1,T-t_stamp,t_stamp):
        g_period_demand_list[t] = {}
    g_period_delivery_list = {}
    for t in range(1,T-t_stamp,t_stamp):
        g_period_delivery_list[t] = [0] * destination_number               
    g_pickup_demand_list = []
    g_delivery_demand_list = []
    g_number_of_delivery_demands = 0
    g_pickup_demand_total_l = [0] * destination_number            

    for t in range(1,T-t_stamp,t_stamp):
        for i in range(1, g_number_of_pickup_nodes):        
            node_type = g_pickup_node_list[i].node_type
            node_id = g_pickup_node_list[i].node_id
            if node_type == 4:
                g_pickup_demand_node_list.append(node_id)
                g_number_of_pickup_demand_nodes += 1         
        stage_demand_total_number.append(g_number_of_pickup_demand_nodes)

        for i in range(1, g_number_of_pickup_demand_nodes):
            g_pickup_demand_list.append([])            
        for i in range(1, g_number_of_nodes):
            node_type = g_node_list[i].node_type
            if node_type < 0:
                g_delivery_demand_list.append([0]*destination_number) 
                g_number_of_delivery_demands += 1

        for i in range(0, g_number_of_pickup_demand_nodes-1):
            for j in range(0,destination_number):            
                if j == 0:                            
                    g_pickup_demand_list[i].append(0) 
                z = random.randint(1,3)
                if j == z:
                    g_pickup_demand_list[i].append(random.randint(0,1))
                if j > 0 and j != z:
                    g_pickup_demand_list[i].append(1)                    
        for j in range(0,destination_number): 
            for i in range(0, g_number_of_pickup_demand_nodes-1):            
                g_pickup_demand_total_l[j] += g_pickup_demand_list[i][j]                    
        for i in range(0, g_number_of_delivery_demands):
            for j in range(1,destination_number):
                if i == j-1:                                                           
                    g_delivery_demand_list[i][j] -=  g_pickup_demand_total_l[j]        
        g_period_delivery_list[t] = g_delivery_demand_list            
        for i in range(0, g_number_of_pickup_demand_nodes-1):            
            g_period_demand_list[t][g_pickup_demand_node_list[i]] = g_pickup_demand_list[i]                        
        for j in range(0,destination_number):        
            stage_destination_total_number[j] += g_pickup_demand_total_l[j]
        each_stage_destination_total_number.append(g_pickup_demand_total_l)
        g_pickup_demand_node_list = []
        g_number_of_pickup_demand_nodes = 1
        g_pickup_demand_list = []
        g_delivery_demand_list = []
        g_number_of_delivery_demands = 0 
        g_pickup_demand_total_l = [0] * destination_number                                                                                                                                        
    return()
def g_generation_initial_model_data():    
    global g_period_demand_list,g_period_delivery_list,g_model_period_list,g_number_of_models 
    g_model_period_list =[]
    g_number_of_models = 0             
    model = Model()
    model.model_period = 0
    g_model_period_list.append(model)        
    g_number_of_models += 1      
    for t in range(1,T-t_stamp,t_stamp): 
        model = Model()
        model.model_period = t
        model.demand_dict = g_period_demand_list[t]
        model.demand_id_list = list(g_period_demand_list[t].keys())
        model.delivery_dict = g_period_delivery_list[t]
        model.scheduled_start_time = t + t_stamp
        for i in range(0,len(g_period_delivery_list[t])):
            model.delivery_id_list.append(g_unloading_node_list[i+1].node_id)        
        for i in range(1,g_number_of_nodes): 
            if (g_node_list[i].node_type == 2):
                model.origin.append(i) 
            if (g_node_list[i].node_type == 3):
                model.destination.append(i)                        
            if (g_node_list[i].link_type == 4):
                model.pickup_depot.append(i) 
            if (g_node_list[i].link_type == 5):
                model.delivery_depot.append(i)                                       
        for i in range(len(model.demand_id_list)):
            from_node_id = model.demand_id_list[i]
            for j in range(i+1,len(model.demand_id_list)):
                to_node_id=model.demand_id_list[j]
                dist= shortest_d_d[from_node_id][to_node_id]
                model.pickup_distance_matrix[from_node_id,to_node_id]=dist
                model.pickup_distance_matrix[to_node_id,from_node_id]=dist            
            for k in range(len(model.pickup_depot)):                                    
                depot_id = model.pickup_depot[k]                
                dist = shortest_d_d[from_node_id][depot_id]
                model.pickup_distance_matrix[from_node_id, depot_id] = dist
                model.pickup_distance_matrix[depot_id, from_node_id] = dist
            for k in range(len(model.origin)):                                    
                origin = model.origin[k]                
                dist = shortest_d_d[from_node_id][origin]
                model.pickup_distance_matrix[from_node_id, origin] = dist
                model.pickup_distance_matrix[origin, from_node_id] = dist                                    
        for i in range(len(model.delivery_id_list)):
            from_node_id = model.delivery_id_list[i]
            for j in range(i+1,len(model.delivery_id_list)):
                to_node_id=model.delivery_id_list[j]
                dist= shortest_d_d[from_node_id][to_node_id]
                model.delivery_distance_matrix[from_node_id,to_node_id]=dist
                model.delivery_distance_matrix[to_node_id,from_node_id]=dist            
            for k in range(len(model.delivery_depot)):                                    
                depot_id = model.delivery_depot[k]                
                dist = shortest_d_d[from_node_id][depot_id]
                model.delivery_distance_matrix[from_node_id, depot_id] = dist
                model.delivery_distance_matrix[depot_id, from_node_id] = dist
            for k in range(len(model.destination)):                                    
                destination = model.destination[k]                
                dist = shortest_d_d[from_node_id][destination]
                model.delivery_distance_matrix[from_node_id, destination] = dist
                model.delivery_distance_matrix[destination, from_node_id] = dist                
        model.rand_d_min = 0.1
        model.rand_d_max = 0.4
        model.worst_d_max= 2
        model.worst_d_min= 1         
        model.shaw_distance_index = 0.5 
        model.shaw_time_index = 0.4 
        model.shaw_demand_index = 0.1
        model.removal_ratio = 0.3
        model.removal_route = 1
        model.regret_n = 2
        model.rho = 0.2
        model.r1 = [6,12,18]
        model.r2 = [2,4,6]
        model.r3 = [1,1,1]  
        model.scheduled_vehicle_cap = 20                                  
        g_model_period_list.append(model)        
        g_number_of_models += 1                                   
    return()
def g_generation_initial_node_list():
    global node_id_list
    node_id_list = []
    for i in range(1,g_number_of_models):
        node_id_list.append([])    
    for i in range(1,g_number_of_models):
        demand_node_list = g_model_period_list[i].demand_id_list        
        node_id_list[i-1] = copy.deepcopy(demand_node_list)       
    return()
def g_generation_initial_solution():    
    global g_solution_period_list,g_number_of_solutions
    g_solution_period_list =[]
    g_number_of_solutions = 0             
    solution = Solution()
    solution.solution_period = 0
    g_solution_period_list.append(solution)        
    g_number_of_solutions += 1      
    for t in range(1,T-t_stamp,t_stamp): 
        solution = Solution()
        solution.solution_period = t
        solution.node_id_list = node_id_list[int((t-1)/t_stamp)]                               
        g_solution_period_list.append(solution)        
        g_number_of_solutions += 1                                  
    #new_solution        
    global g_solution_period_list_new,g_number_of_solutions_new 
    g_solution_period_list_new =[]
    g_number_of_solutions_new = 0             
    solution_new = Solution()
    solution_new.solution_period = 0
    g_solution_period_list_new.append(solution_new)        
    g_number_of_solutions_new += 1          
    for t in range(1,T-t_stamp,t_stamp): 
        solution_new = Solution()
        solution_new.solution_period = t
        solution_new.node_id_list = node_id_list[int((t-1)/t_stamp)]                                                
        g_solution_period_list_new.append(solution_new)        
        g_number_of_solutions_new += 1
    return()    

def g_generation_initial_pickup_solution():
    global num_pickup_vehicles,pickup_vehicles,total_pickup_routes
    global total_pickup_times,total_pickup_distances     
    num_pickup_vehicles = 0
    pvehicles = 0
    pickup_vehicles = []      
    total_pickup_routes = []
    pickup_route_cap = []
    pickup_route = []          
    total_pickup_times = []
    total_pickup_distances = [] 
    distance = 0
    runtime = 0
    each_logistics_vehicle_time = 0    
    for i in range(1,g_number_of_models):
        total_pickup_routes.append([])
        total_pickup_times.append([])
        total_pickup_distances.append([])                
    for i in range(1,g_number_of_models):     
        demand_node_id_list = g_solution_period_list[i].node_id_list
        demand_node_dict = g_model_period_list[i].demand_dict  #each demand node number        
        remained_cap = g_model_period_list[i].logistics_vehicle_cap #cap
        remained_time = g_model_period_list[i].maximum_pickup_time - transfer_time
        pickup_depot= g_model_period_list[i].pickup_depot
        origin = g_model_period_list[i].origin
        pickup_distance_matrix = g_model_period_list[i].pickup_distance_matrix        
        
        for j in range(len(demand_node_id_list)):
            demand_node = demand_node_id_list[j]
            start_time = g_node_list[demand_node].start_time
            end_time = g_node_list[demand_node].end_time
            demand_node_number = sum(demand_node_dict[demand_node])                     
            if remained_cap - demand_node_number >= 0 :                                                                                                                                       
                pickup_route_cap.append(demand_node)
                remained_cap = remained_cap - demand_node_number
                #time              
                mid_pickup_distance = 0
                time_min_distance = float('inf')
                time_index = None
                for depot_id in pickup_depot:
                    for origin_id in origin:
                        time_distance = pickup_distance_matrix[origin_id,pickup_route_cap[0]] + pickup_distance_matrix[pickup_route_cap[-1],depot_id]                    
                        if time_distance < time_min_distance:
                            time_index = depot_id
                            time_min_distance = time_distance                  
                pickup_route_cap.insert(0,origin[0])
                pickup_route_cap.append(time_index)               
                for route_id in range(len(pickup_route_cap)-1):                        
                    mid_pickup_distance += pickup_distance_matrix[pickup_route_cap[route_id],pickup_route_cap[route_id + 1]]
                mid_calculate_pickup_time = math.ceil(mid_pickup_distance/logistics_vehicle_speed) + (len(pickup_route_cap)-2) * service_time                                                                                                                 
                if remained_time - mid_calculate_pickup_time >= 0 and mid_calculate_pickup_time >= start_time and mid_calculate_pickup_time<= end_time:                
                    pickup_route.append(demand_node)
                    pickup_route_cap.pop(0)
                    pickup_route_cap.pop()
                else:
                    min_in_out_distance = float('inf')
                    index = None
                    for depot_id in pickup_depot:                
                        in_out_distance = pickup_distance_matrix[origin[0],pickup_route[0]] + pickup_distance_matrix[pickup_route[-1],depot_id]                    
                        if in_out_distance < min_in_out_distance:
                            index = depot_id
                            min_in_out_distance = in_out_distance                                              
                    pickup_route.insert(0,origin[0])
                    pickup_route.append(index)                                                                                                
                    total_pickup_routes[i-1].append(pickup_route)                
                    num_pickup_vehicles += 1
                    pvehicles += 1 
                    pickup_route = [demand_node]
                    pickup_route_cap = [demand_node]                    
                    remained_cap = g_model_period_list[i].logistics_vehicle_cap - demand_node_number                                                   
            else:
                min_in_out_distance = float('inf')
                index = None
                for depot_id in pickup_depot:                
                    in_out_distance = pickup_distance_matrix[origin[0],pickup_route_cap[0]] + pickup_distance_matrix[pickup_route_cap[-1],depot_id]                    
                    if in_out_distance < min_in_out_distance:
                        index=depot_id
                        min_in_out_distance = in_out_distance                                              
                pickup_route_cap.insert(0,origin[0])
                pickup_route_cap.append(index)                                       
                total_pickup_routes[i-1].append(pickup_route_cap)                
                num_pickup_vehicles += 1
                pvehicles += 1
                pickup_route = [demand_node]
                pickup_route_cap = [demand_node]               
                remained_cap = g_model_period_list[i].logistics_vehicle_cap - demand_node_number                               
                
        min_in_out_distance = float('inf')
        index = None
        for depot_id in pickup_depot:
            in_out_distance = pickup_distance_matrix[origin[0],pickup_route_cap[0]] + pickup_distance_matrix[pickup_route_cap[-1],depot_id]                    
            if in_out_distance < min_in_out_distance:
                index = depot_id
                min_in_out_distance = in_out_distance
        pickup_route_cap.insert(0,origin[0])
        pickup_route_cap.append(index)                                       
        total_pickup_routes[i-1].append(pickup_route_cap)
        num_pickup_vehicles += 1 
        pvehicles += 1
        pickup_route_cap = []
        pickup_route = []
        pickup_vehicles.append(pvehicles)
        pvehicles = 0       
    #pickup_stage_sum              
    for i in range(1,g_number_of_models):    
        stage_a = total_pickup_routes[i-1]
        for j in range(len(stage_a)):
            stage_b = stage_a[j]
            for k in range(len(stage_b)-1):            
                from_node = stage_b[k]
                to_node = stage_b[k+1]
                distance += g_model_period_list[i].pickup_distance_matrix[from_node,to_node]                  
            runtime += math.ceil(distance/logistics_vehicle_speed)
            each_logistics_vehicle_time += runtime + service_time * (len(stage_b)-2) 
            total_pickup_distances[i-1].append(distance)
            total_pickup_times[i-1].append(each_logistics_vehicle_time)
            distance = 0
            runtime = 0
            each_logistics_vehicle_time = 0                                                        
    return()

def g_generation_initial_pickup_solution_new():
    global num_pickup_vehicles,pickup_vehicles,total_pickup_routes
    global total_pickup_times,total_pickup_distances     
    num_pickup_vehicles = 0
    pvehicles = 0
    pickup_vehicles = []      
    total_pickup_routes = []
    pickup_route_cap = []
    pickup_route = []          
    total_pickup_times = []
    total_pickup_distances = [] 
    distance = 0
    runtime = 0
    each_logistics_vehicle_time = 0    
    for i in range(1,g_number_of_models):
        total_pickup_routes.append([])
        total_pickup_times.append([])
        total_pickup_distances.append([])                
    for i in range(1,g_number_of_models):     
        demand_node_id_list = g_solution_period_list[i].node_id_list
        demand_node_dict = g_model_period_list[i].demand_dict  #each demand node number        
        remained_cap = g_model_period_list[i].logistics_vehicle_cap #cap
        remained_time = g_model_period_list[i].maximum_pickup_time - transfer_time
        pickup_depot= g_model_period_list[i].pickup_depot
        origin = g_model_period_list[i].origin
        pickup_distance_matrix = g_model_period_list[i].pickup_distance_matrix                
        for j in range(len(demand_node_id_list)):
            demand_node = demand_node_id_list[j]
            start_time = g_node_list[demand_node].start_time
            end_time = g_node_list[demand_node].end_time
            demand_node_number = sum(demand_node_dict[demand_node])                     
            if remained_cap - demand_node_number >= 0 :                                                                                                                                       
                pickup_route_cap.append(demand_node)
                remained_cap = remained_cap - demand_node_number
                #time              
                mid_pickup_distance = 0
                time_min_distance = float('inf')
                time_index = None
                for depot_id in pickup_depot:
                    for origin_id in origin:
                        time_distance = pickup_distance_matrix[origin_id,pickup_route_cap[0]] + pickup_distance_matrix[pickup_route_cap[-1],depot_id]                    
                        if time_distance < time_min_distance:
                            time_index = depot_id
                            time_min_distance = time_distance                  
                pickup_route_cap.insert(0,origin[0])
                pickup_route_cap.append(time_index)               
                for route_id in range(len(pickup_route_cap)-1):                        
                    mid_pickup_distance += pickup_distance_matrix[pickup_route_cap[route_id],pickup_route_cap[route_id + 1]]
                mid_calculate_pickup_time = math.ceil(mid_pickup_distance/logistics_vehicle_speed) + (len(pickup_route_cap)-2) * service_time                                                                                                                 
                if remained_time - mid_calculate_pickup_time >= 0 and mid_calculate_pickup_time >= start_time and mid_calculate_pickup_time<= end_time:                
                    pickup_route.append(demand_node)
                    pickup_route_cap.pop(0)
                    pickup_route_cap.pop()
                else:
                    min_in_out_distance = float('inf')
                    index = None
                    for depot_id in pickup_depot:                
                        in_out_distance = pickup_distance_matrix[origin[0],pickup_route[0]] + pickup_distance_matrix[pickup_route[-1],depot_id]                    
                        if in_out_distance < min_in_out_distance:
                            index = depot_id
                            min_in_out_distance = in_out_distance                                              
                    pickup_route.insert(0,origin[0])
                    pickup_route.append(index)                                                                                                
                    total_pickup_routes[i-1].append(pickup_route)                
                    num_pickup_vehicles += 1
                    pvehicles += 1 
                    pickup_route = [demand_node]
                    pickup_route_cap = [demand_node]                    
                    remained_cap = g_model_period_list[i].logistics_vehicle_cap - demand_node_number                                                   
            else:
                min_in_out_distance = float('inf')
                index = None
                for depot_id in pickup_depot:                
                    in_out_distance = pickup_distance_matrix[origin[0],pickup_route_cap[0]] + pickup_distance_matrix[pickup_route_cap[-1],depot_id]                    
                    if in_out_distance < min_in_out_distance:
                        index=depot_id
                        min_in_out_distance = in_out_distance                                              
                pickup_route_cap.insert(0,origin[0])
                pickup_route_cap.append(index)                                       
                total_pickup_routes[i-1].append(pickup_route_cap)                
                num_pickup_vehicles += 1
                pvehicles += 1
                pickup_route = [demand_node]
                pickup_route_cap = [demand_node]               
                remained_cap = g_model_period_list[i].logistics_vehicle_cap - demand_node_number                               
                
        min_in_out_distance = float('inf')
        index = None
        for depot_id in pickup_depot:
            in_out_distance = pickup_distance_matrix[origin[0],pickup_route_cap[0]] + pickup_distance_matrix[pickup_route_cap[-1],depot_id]                    
            if in_out_distance < min_in_out_distance:
                index = depot_id
                min_in_out_distance = in_out_distance
        pickup_route_cap.insert(0,origin[0])
        pickup_route_cap.append(index)                                       
        total_pickup_routes[i-1].append(pickup_route_cap)
        num_pickup_vehicles += 1 
        pvehicles += 1
        pickup_route_cap = []
        pickup_route = []
        pickup_vehicles.append(pvehicles)
        pvehicles = 0       
    #pickup_stage_sum              
    for i in range(1,g_number_of_models):    
        stage_a = total_pickup_routes[i-1]
        for j in range(len(stage_a)):
            stage_b = stage_a[j]
            for k in range(len(stage_b)-1):            
                from_node = stage_b[k]
                to_node = stage_b[k+1]
                distance += g_model_period_list[i].pickup_distance_matrix[from_node,to_node]                  
            runtime += math.ceil(distance/logistics_vehicle_speed)
            each_logistics_vehicle_time += runtime + service_time * (len(stage_b)-2) 
            total_pickup_distances[i-1].append(distance)
            total_pickup_times[i-1].append(each_logistics_vehicle_time)
            distance = 0
            runtime = 0
            each_logistics_vehicle_time = 0                                                        
    return()

def pickup_demand_connect():
    global demand_pickup_times,demand_pickup_routes,demand_pickup_distances,demand_pickup_vehicles_stage,demand_pickup_demands_dict,demand_pickup_position
    demand_pickup_times = []
    demand_pickup_routes = []
    demand_pickup_distances = []
    demand_pickup_vehicles_stage = []
    demand_pickup_demands_dict = {}
    demand_pickup_position = []
    z = 0
    for i in range(1,g_number_of_models):
        demand_pickup_times.append([])
        demand_pickup_routes.append([])
        demand_pickup_distances.append([])
        demand_pickup_position.append([])
        demand_pickup_demands_dict[i] = {}        
    #Requirements are passed to the next stage
    for i in range(1,g_number_of_models):
        pickup_times = total_pickup_times[i-1]
        remained_time = g_model_period_list[i].maximum_pickup_time
        pickup_routes = total_pickup_routes[i-1]
        pickup_distances = total_pickup_distances[i-1]        
        pickup_demands_dict = g_model_period_list[i].demand_dict
        demand_node_id_list = g_solution_period_list[i].node_id_list
        for j in range(len(pickup_times)):
            if pickup_times[j] > remained_time:
               demand_pickup_times[i-1].append(pickup_times[j] - remained_time)               
               demand_pickup_routes[i-1].append(pickup_routes[j])
               demand_pickup_distances[i-1].append(pickup_distances[j])
               demand_pickup_position[i-1].append(j)                              
               for pickup_routes_id in pickup_routes[j]:
                   if pickup_routes_id in demand_node_id_list:
                       demand_pickup_demands_dict[i][pickup_routes_id] = pickup_demands_dict[pickup_routes_id]
               z = z + 1                              
        demand_pickup_vehicles_stage.append(z)
        z = 0            
    return()      
def pickup_scheduled_connect():    
    global origin_scheduled_demands,cross_pickup_demands                            
    origin_scheduled_demands = {}
    demands = [0] * destination_number
    list1 = []       
    pickup_demands1 = [0] * destination_number         
    for i in range(1,g_number_of_models):          
        origin_scheduled_demands[i] = {} 
    #pickup_schedule_connect            
    for i in range(1,g_number_of_models): 
        pickup_depot= g_model_period_list[i].pickup_depot
        for j in range(len(pickup_depot)):
            origin_scheduled_demands[i][pickup_depot[j]] = demands             
    for i in range(1,g_number_of_models):
        pickup_depot= g_model_period_list[i].pickup_depot        
        pickup_routes = total_pickup_routes[i-1]
        pickup_demands_dict = g_model_period_list[i].demand_dict
        origin = g_model_period_list[i].origin
        for j in range(len(pickup_routes)):
            if pickup_routes[j][-1] == pickup_depot[0]:
                list1 += pickup_routes[j]                             
        list1 = list(set(list1))
        list1.remove(origin[0])
        list1.remove(pickup_depot[0])                                          
        for j in range(len(list1)):
            for k in range(len(pickup_demands_dict[list1[j]])):                            
                pickup_demands1[k] += pickup_demands_dict[list1[j]][k]
        origin_scheduled_demands[i][pickup_depot[0]] = pickup_demands1                                                                
        list1 = []
        pickup_demands1 = [0] * destination_number                
    #transfer demand
    pickup_demands3 = [0] * destination_number
    cross_pickup_demands = 0
    for i in range(1,g_number_of_models):
        pickup_depot= g_model_period_list[i].pickup_depot
        demand_pickup_routes_stage  = demand_pickup_routes[i-1]
        demand_pickup_demands_dict_stage = demand_pickup_demands_dict[i]        
        for index_id in range(len(demand_pickup_routes_stage)):            
            if demand_pickup_routes_stage[index_id][-1] == pickup_depot[0]:
                for k in range(len(demand_pickup_demands_dict_stage[demand_pickup_routes_stage[index_id][1]])):                            
                    pickup_demands3[k] += demand_pickup_demands_dict_stage[demand_pickup_routes_stage[index_id][1]][k]                                                 
        for z in range(0,destination_number):
            origin_scheduled_demands[i][pickup_depot[0]][z] -= pickup_demands3[z]              
            if i < g_number_of_models-1:                
                origin_scheduled_demands[i+1][pickup_depot[0]][z] += pickup_demands3[z]              
        for z in range(0,destination_number):            
            cross_pickup_demands += pickup_demands3[z]
        pickup_demands3 = [0] * destination_number                           
    return()    

def g_generation_initial_scheduled_solution():    
    global num_scheduled_vehicles,num_scheduled_freights,scheduled_vehicles,scheduled_freights,num_scheduled_vehicles1,num_scheduled_vehicles2,num_scheduled_freights1,num_scheduled_freights2
    global destination_scheduled_demands,total_scheduled_times,total_scheduled_distances,total_freight_times,total_scheduled_routes
    num_scheduled_vehicles = 0
    num_scheduled_freights = 0
    vehicles1 = 0
#    vehicles2 = 0
    freights1 = 0
#    freights2 = 0
    scheduled_vehicles = []
    scheduled_freights = []
    total_scheduled_routes = []
    total_scheduled_distances = []
    total_scheduled_times = []
    total_freight_times = []
    
    for i in range(1,g_number_of_models):
        total_scheduled_routes.append([])
        total_scheduled_distances.append([])
        total_scheduled_times.append([])
        total_freight_times.append([])
        scheduled_vehicles.append([])
        scheduled_freights.append([])
    for i in range(1,g_number_of_models):
        pickup_depot = g_model_period_list[i].pickup_depot
        for j in range(len(pickup_depot)):
           total_scheduled_routes[i-1].append([])           
    for i in range(1,g_number_of_models):
        pickup_depot = g_model_period_list[i].pickup_depot
        delivery_depot = g_model_period_list[i].delivery_depot           
        delivery_depot.reverse()        
        for j in range(len(pickup_depot)):   
            total_scheduled_routes[i-1][j].append(pickup_depot[j])            
        for j in range(len(delivery_depot)):        
            total_scheduled_routes[i-1][j].append(delivery_depot[j])
    for i in range(1,g_number_of_models):
        pickup_depot = g_model_period_list[i].pickup_depot
        delivery_depot = g_model_period_list[i].delivery_depot           
        delivery_depot.reverse() 
        for j in range(len(pickup_depot)):
            from_node_id = total_scheduled_routes[i-1][j][0]
            to_node_id = total_scheduled_routes[i-1][j][1]
            dist= shortest_d_d[from_node_id][to_node_id]
            total_scheduled_distances[i-1].append(dist)
            total_scheduled_times[i-1].append(math.ceil(dist/scheduled_vehicle_speed) + i * t_stamp)            
            total_freight_times[i-1].append(math.ceil(dist/logistics_vehicle_speed) + i * t_stamp)                    
    # destination_scheduled_demands           
    destination_scheduled_demands = {}
    scheduled_demands = []
    sum_scheduled_demands = 0
    demands = [0] * destination_number      
    for i in range(1,g_number_of_models):          
        destination_scheduled_demands[i] = {}
        scheduled_demands.append([])
    for i in range(1,g_number_of_models):         
        delivery_depot = g_model_period_list[i].delivery_depot           
        delivery_depot.reverse()
        for j in range(len(delivery_depot)):
            demands = origin_scheduled_demands[i][pickup_depot[j]]
            sum_scheduled_demands = sum(demands)
            destination_scheduled_demands[i][delivery_depot[j]] = demands
            scheduled_demands[i-1].append(sum_scheduled_demands)
            demands = [0] * destination_number
            sum_scheduled_demands = 0
    #num_scheduled_vehicles,num_scheduled_freights
    a1 = 0
    b1 = 0    
    num_scheduled_freights1 = 0
    num_scheduled_vehicles1 = 0      
    for i in range(1,g_number_of_models):     
        each_scheduled_demands = scheduled_demands[i-1]
        scheduled_vehicle_cap = g_model_period_list[i].scheduled_vehicle_cap
        scheduled_freight_cap = g_model_period_list[i].scheduled_freight_cap                               
        first_node_scheduled_demands = each_scheduled_demands[0]
        a1 = first_node_scheduled_demands // scheduled_freight_cap
        b1 = first_node_scheduled_demands % scheduled_freight_cap
        num_scheduled_freights1 += a1
        freights1 += a1
        if b1 > scheduled_vehicle_cap and b1 < scheduled_freight_cap:
            num_scheduled_freights1 += 1
            freights1 += 1
        if b1 > 0 and b1 <=scheduled_vehicle_cap:
            num_scheduled_vehicles1 += 1 
            vehicles1 += 1
        scheduled_vehicles[i-1].append(vehicles1)
        scheduled_freights[i-1].append(freights1)
        freights1 = 0
        vehicles1 = 0               
    num_scheduled_vehicles = num_scheduled_vehicles1 
    num_scheduled_freights = num_scheduled_freights1 
    return()  
def g_generation_initial_delivery_solution():

    global num_delivery_vehicles,delivery_vehicles,total_delivery_routes
    global total_delivery_times,total_delivery_distances,total_delivery_demands        
    num_delivery_vehicles = 0 
    dvehicles = 0
    delivery_vehicles = []  
    total_delivery_routes = []    
    delivery_route = []
    delivery_route_time = []
    total_delivery_demands = copy.deepcopy(destination_scheduled_demands)    
    for i in range(1,g_number_of_models):
        total_delivery_routes.append([])
    # >cap       
    for i in range(1,g_number_of_models):
        delivery_depot = g_model_period_list[i].delivery_depot 
        destination = g_model_period_list[i].destination
        delivery_cap = g_model_period_list[i].logistics_vehicle_cap
        delivery_id_list = g_model_period_list[i].delivery_id_list        
        for j in range(len(delivery_depot)):
            demand_node = total_delivery_demands[i][delivery_depot[j]]        
            for k in range(len(demand_node)-1):
                each_delivery_node = delivery_id_list[k]
                if demand_node[k+1] >= delivery_cap:                                                     
                    num_delivery_vehicles += 1
                    dvehicles += 1
                    demand_node[k+1] -= delivery_cap
                    delivery_route.append(delivery_depot[j])
                    delivery_route.append(each_delivery_node)
                    delivery_route.append(destination[0])
                    total_delivery_routes[i-1].append(delivery_route)
                    delivery_route = [] 
        delivery_vehicles.append(dvehicles)
        dvehicles = 0
    # < cap
    for i in range(1,g_number_of_models):
        delivery_depot = g_model_period_list[i].delivery_depot        
        delivery_cap = g_model_period_list[i].logistics_vehicle_cap
        remained_delivery_time = g_model_period_list[i].maximum_delivery_time
        destination = g_model_period_list[i].destination
        delivery_id_list = g_model_period_list[i].delivery_id_list
        delivery_distance_matrix = g_model_period_list[i].delivery_distance_matrix
        for j in range(len(delivery_depot)):
            demand_node = total_delivery_demands[i][delivery_depot[j]]        
            for k in range(len(delivery_id_list)):
                each_delivery_demands = demand_node[k+1]                                
                each_delivery_node = delivery_id_list[k]               
                if each_delivery_demands > 0:
                    
                    if delivery_cap - each_delivery_demands >= 0:
                        delivery_route.append(each_delivery_node)
                        delivery_cap = delivery_cap - each_delivery_demands                   
                        #time                               
                        mid_delivery_distance = 0
                        delivery_route.insert(0,delivery_depot[j])
                        delivery_route.append(destination[0])
                        for route_id in range(len(delivery_route)-1):                        
                            mid_delivery_distance += delivery_distance_matrix[delivery_route[route_id],delivery_route[route_id + 1]]
                        mid_calculate_delivery_time = math.ceil(mid_delivery_distance/logistics_vehicle_speed) + (len(delivery_route)-2) * service_time                                                                                                                 
                        if remained_delivery_time - mid_calculate_delivery_time >= 0:                
                            delivery_route_time.append(each_delivery_node)
                            delivery_route.pop(0)
                            delivery_route.pop()
                        else:                                              
                            index = delivery_depot[j]
                            delivery_route_time.insert(0,index)
                            delivery_route_time.append(destination[0])                                                                                                                            
                            total_delivery_routes[i-1].append(delivery_route_time)                
                            num_delivery_vehicles += 1
                            dvehicles += 1 
                            delivery_route = [each_delivery_node]
                            delivery_route_time = [each_delivery_node]                    
                            delivery_cap = g_model_period_list[i].logistics_vehicle_cap - each_delivery_demands                 
                    else:
                        index = delivery_depot[j]
                        delivery_route.insert(0,index)
                        delivery_route.append(destination[0])                                      
                        total_delivery_routes[i-1].append(delivery_route)                
                        num_delivery_vehicles += 1 
                        dvehicles += 1 
                        delivery_route_time = [each_delivery_node]
                        delivery_route = [each_delivery_node]
                        delivery_cap = g_model_period_list[i].logistics_vehicle_cap - each_delivery_demands                    
            
            index = delivery_depot[j]
            delivery_route.insert(0,index)
            delivery_route.append(destination[0])                                    
            total_delivery_routes[i-1].append(delivery_route)
            num_delivery_vehicles += 1
            dvehicles += 1 
            delivery_route = [] 
            delivery_route_time = []                    
            delivery_cap = g_model_period_list[i].logistics_vehicle_cap  
        delivery_vehicles[i-1] += dvehicles
        dvehicles = 0            


    for i in range(1,g_number_of_models):
        delivery_depot = g_model_period_list[i].delivery_depot        
        destination = g_model_period_list[i].destination                
        if [delivery_depot[0],destination[0]] in total_delivery_routes[i-1]:            
            total_delivery_routes[i-1].remove([delivery_depot[0],destination[0]])
            delivery_vehicles[i-1] -= 1
            num_delivery_vehicles -= 1               
    #demand total_delivery_times,total_delivery_distances
    total_delivery_times = []
    total_delivery_distances = [] 
    distance = 0
    runtime = 0
    each_logistics_vehicle_time = 0  
    for i in range(1,g_number_of_models):          
        total_delivery_times.append([])
        total_delivery_distances.append([])        
    for i in range(1,g_number_of_models):    
        stage_a = total_delivery_routes[i-1]
        for j in range(len(stage_a)):
            stage_b = stage_a[j]
            for k in range(len(stage_b)-1):            
                from_node = stage_b[k]
                to_node = stage_b[k+1]
                distance += g_model_period_list[i].delivery_distance_matrix[from_node,to_node]                  
            runtime += math.ceil(distance/logistics_vehicle_speed)
            each_logistics_vehicle_time += runtime + service_time * (len(stage_b)-2) 
            total_delivery_distances[i-1].append(distance)
            total_delivery_times[i-1].append(each_logistics_vehicle_time)
            distance = 0
            runtime = 0
            each_logistics_vehicle_time = 0    
    return()
def g_generation_calObj():

    global total_cost,total_saving_cost
    global total_pickup_cost,fixed_pickup_cost,total_delivery_cost,fixed_delivery_cost,total_scheduled_cost,fixed_scheduled_cost
    global pickup_cost,fixed_pickup,delivery_cost,fixed_delivery,scheduled_cost,fixed_scheduled,saving_fixed_cost,saving_cost
    global stage_total_cost,stage_total_pickup_cost,stage_total_delivery_cost,stage_total_scheduled_cost,stage_total_saving_cost     
    global penalty_cost
    total_cost = 0    
    pickup_cost = []
    fixed_pickup = []
    total_pickup_cost = 0 
    fixed_pickup_cost = 0    
    delivery_cost = []
    fixed_delivery = []
    total_delivery_cost = 0
    fixed_delivery_cost = 0
    fixed_scheduled_cost = 0
    total_scheduled_cost = 0
    scheduled_cost = []
    fixed_scheduled = []
    saving_cost = []
    saving_fixed_cost = []
    total_saving_cost = 0
   
    stage_pickup_distances = 0
    total_stage_pickup_distances = 0        
    stage_delivery_distances = 0
    total_stage_delivery_distances = 0     
    stage_scheduled_distances = 0
    total_stage_scheduled_distances = 0 
    saving_distances = 0
    total_saving_distances = 0

    stage_total_cost = []
    stage_total_pickup_cost = []
    stage_total_delivery_cost = []
    stage_total_scheduled_cost = []
    stage_total_saving_cost = [] 

    penalty_cost = each_penalty_cost * cross_pickup_demands
        
    for i in range(1,g_number_of_models):
        pickup_distance = total_pickup_distances[i-1]
        for j in range(len(pickup_distance)):
            stage_pickup_distances += pickup_distance[j]
            total_stage_pickup_distances += pickup_distance[j]
        pickup_cost.append(stage_pickup_distances * traffic_logistics_vehicle_cost/1)
        fixed_pickup.append(pickup_vehicles[i-1] * fixed_logistics_vehicle_cost)
        stage_pickup_distances = 0
    fixed_pickup_cost += num_pickup_vehicles * fixed_logistics_vehicle_cost            
    total_pickup_cost += total_stage_pickup_distances * traffic_logistics_vehicle_cost/1

    for i in range(1,g_number_of_models):
        delivery_distance = total_delivery_distances[i-1]
        for j in range(len(delivery_distance)):
            stage_delivery_distances += delivery_distance[j] 
            total_stage_delivery_distances += delivery_distance[j]
        delivery_cost.append(stage_delivery_distances * traffic_logistics_vehicle_cost/1)
        fixed_delivery.append(delivery_vehicles[i-1] * fixed_logistics_vehicle_cost)
        stage_delivery_distances = 0
    fixed_delivery_cost += num_delivery_vehicles * fixed_logistics_vehicle_cost
    total_delivery_cost += total_stage_delivery_distances * traffic_logistics_vehicle_cost/1

    for i in range(1,g_number_of_models):
        scheduled_distance = total_scheduled_distances[i-1]
        stage_scheduled_distances +=  scheduled_distance[0] * scheduled_freights[i-1][0]
        total_stage_scheduled_distances += scheduled_distance[0] * scheduled_freights[i-1][0]
        scheduled_cost.append(stage_scheduled_distances * traffic_scheduled_freight_cost/1)
        fixed_scheduled.append(scheduled_freights[i-1][0] * fixed_scheduled_freight_cost)
        stage_scheduled_distances = 0
        
        saving_distances += scheduled_distance[0] * scheduled_vehicles[i-1][0]
        total_saving_distances += scheduled_distance[0] * scheduled_vehicles[i-1][0]
        saving_cost.append(saving_distances * traffic_scheduled_freight_cost/1)
        saving_fixed_cost.append(scheduled_vehicles[i-1][0] * fixed_scheduled_freight_cost)
        saving_distances = 0
    fixed_scheduled_cost +=  num_scheduled_freights * fixed_scheduled_freight_cost        
    total_scheduled_cost += total_stage_scheduled_distances * traffic_scheduled_freight_cost/1
    total_saving_cost += num_scheduled_vehicles * fixed_scheduled_freight_cost + total_saving_distances * traffic_scheduled_freight_cost/1    
    total_cost += total_pickup_cost + total_delivery_cost + total_scheduled_cost + fixed_pickup_cost + fixed_delivery_cost + fixed_scheduled_cost + penalty_cost                               
    for i in range(1,g_number_of_models):    
        stage_total_pickup_cost.append(pickup_cost[i-1] + fixed_pickup[i-1])
        stage_total_delivery_cost.append(delivery_cost[i-1] + fixed_delivery[i-1])
        stage_total_scheduled_cost.append(scheduled_cost[i-1] + fixed_scheduled[i-1])
        stage_total_saving_cost.append(saving_cost[i-1] + saving_fixed_cost[i-1])               
    for i in range(1,g_number_of_models):
        stage_total_cost.append(stage_total_pickup_cost[i-1] + stage_total_delivery_cost[i-1] + stage_total_scheduled_cost[i-1])            
    return() 

def g_generation_calObj_new():

    global total_cost_new,total_saving_cost_new
    global total_pickup_cost_new,fixed_pickup_cost_new,total_delivery_cost_new,fixed_delivery_cost_new,total_scheduled_cost_new,fixed_scheduled_cost_new
    global pickup_cost_new,fixed_pickup_new,delivery_cost_new,fixed_delivery_new,scheduled_cost_new,fixed_scheduled_new,saving_fixed_cost_new,saving_cost_new
    global stage_total_cost_new,stage_total_pickup_cost_new,stage_total_delivery_cost_new,stage_total_scheduled_cost_new,stage_total_saving_cost_new     
    global penalty_cost_new
    total_cost_new = 0    
    pickup_cost_new = []
    fixed_pickup_new = []
    total_pickup_cost_new = 0 
    fixed_pickup_cost_new = 0    
    delivery_cost_new = []
    fixed_delivery_new = []
    total_delivery_cost_new = 0
    fixed_delivery_cost_new = 0
    fixed_scheduled_cost_new = 0
    total_scheduled_cost_new = 0
    scheduled_cost_new = []
    fixed_scheduled_new = []
    saving_cost_new = []
    saving_fixed_cost_new = []    
    total_saving_cost_new = 0
   
    stage_pickup_distances = 0
    total_stage_pickup_distances = 0        
    stage_delivery_distances = 0
    total_stage_delivery_distances = 0     
    stage_scheduled_distances = 0
    total_stage_scheduled_distances = 0 
    saving_distances = 0
    total_saving_distances = 0

    stage_total_cost_new = []
    stage_total_pickup_cost_new = []
    stage_total_delivery_cost_new = []
    stage_total_scheduled_cost_new = []
    stage_total_saving_cost_new = []

    penalty_cost_new = each_penalty_cost * cross_pickup_demands
   
    for i in range(1,g_number_of_models):
        pickup_distance = total_pickup_distances[i-1]
        for j in range(len(pickup_distance)):
            stage_pickup_distances += pickup_distance[j]
            total_stage_pickup_distances += pickup_distance[j]
        pickup_cost_new.append(stage_pickup_distances * traffic_logistics_vehicle_cost/1)
        fixed_pickup_new.append(pickup_vehicles[i-1] * fixed_logistics_vehicle_cost)
        stage_pickup_distances = 0
    fixed_pickup_cost_new += num_pickup_vehicles * fixed_logistics_vehicle_cost            
    total_pickup_cost_new += total_stage_pickup_distances * traffic_logistics_vehicle_cost/1

    for i in range(1,g_number_of_models):
        delivery_distance = total_delivery_distances[i-1]
        for j in range(len(delivery_distance)):
            stage_delivery_distances += delivery_distance[j] 
            total_stage_delivery_distances += delivery_distance[j]
        delivery_cost_new.append(stage_delivery_distances * traffic_logistics_vehicle_cost/1)
        fixed_delivery_new.append(delivery_vehicles[i-1] * fixed_logistics_vehicle_cost)
        stage_delivery_distances = 0
    fixed_delivery_cost_new += num_delivery_vehicles * fixed_logistics_vehicle_cost
    total_delivery_cost_new += total_stage_delivery_distances * traffic_logistics_vehicle_cost/1

    for i in range(1,g_number_of_models):
        scheduled_distance = total_scheduled_distances[i-1]
        stage_scheduled_distances +=  scheduled_distance[0] * scheduled_freights[i-1][0]
        total_stage_scheduled_distances += scheduled_distance[0] * scheduled_freights[i-1][0]
        scheduled_cost_new.append(stage_scheduled_distances * traffic_scheduled_freight_cost/1)
        fixed_scheduled_new.append(scheduled_freights[i-1][0] * fixed_scheduled_freight_cost)
        stage_scheduled_distances = 0
        
        saving_distances += scheduled_distance[0] * scheduled_vehicles[i-1][0]
        total_saving_distances += scheduled_distance[0] * scheduled_vehicles[i-1][0]
        saving_cost_new.append(saving_distances * traffic_scheduled_freight_cost/1)
        saving_fixed_cost_new.append(scheduled_vehicles[i-1][0] * fixed_scheduled_freight_cost)
        saving_distances = 0

    fixed_scheduled_cost_new +=  num_scheduled_freights * fixed_scheduled_freight_cost        
    total_scheduled_cost_new += total_stage_scheduled_distances * traffic_scheduled_freight_cost/1
    total_saving_cost_new += num_scheduled_vehicles * fixed_scheduled_freight_cost + total_saving_distances * traffic_scheduled_freight_cost/1   
    total_cost_new += total_pickup_cost_new + total_delivery_cost_new + total_scheduled_cost_new + fixed_pickup_cost_new + fixed_delivery_cost_new + fixed_scheduled_cost_new + penalty_cost_new                            

    for i in range(1,g_number_of_models):    
        stage_total_pickup_cost_new.append(pickup_cost_new[i-1] + fixed_pickup_new[i-1])
        stage_total_delivery_cost_new.append(delivery_cost_new[i-1] + fixed_delivery_new[i-1])
        stage_total_scheduled_cost_new.append(scheduled_cost_new[i-1] + fixed_scheduled_new[i-1])
        stage_total_saving_cost_new.append(saving_cost_new[i-1] + saving_fixed_cost_new[i-1])               
    for i in range(1,g_number_of_models):
        stage_total_cost_new.append(stage_total_pickup_cost_new[i-1] + stage_total_delivery_cost_new[i-1] + stage_total_scheduled_cost_new[i-1])

    for i in range(1,g_number_of_models):
        g_solution_period_list_new[i].obj = total_cost_new
        g_solution_period_list_new[i].stage_obj = stage_total_cost_new[i-1]
        g_solution_period_list_new[i].pickup_obj = stage_total_pickup_cost_new[i-1]
        g_solution_period_list_new[i].freight_obj = stage_total_saving_cost_new[i-1]
        g_solution_period_list_new[i].scheduled_obj = stage_total_scheduled_cost_new[i-1]
        g_solution_period_list_new[i].delivery_obj = stage_total_delivery_cost_new[i-1]                
        g_solution_period_list_new[i].pickup_routes = total_pickup_routes[i-1]
        g_solution_period_list_new[i].pickup_time = total_pickup_times[i-1]
        g_solution_period_list_new[i].scheduled_routes = total_scheduled_routes[i-1]
        g_solution_period_list_new[i].scheduled_time = total_scheduled_times[i-1]
        g_solution_period_list_new[i].delivery_routes = total_delivery_routes[i-1]
        g_solution_period_list_new[i].delivery_time = total_delivery_times[i-1]            
        g_solution_period_list_new[i].tran_pickup_obj = pickup_cost_new[i-1]
        g_solution_period_list_new[i].fixed_pickup_obj = fixed_pickup_new[i-1]                
        g_solution_period_list_new[i].tran_delivery_obj = delivery_cost_new[i-1]
        g_solution_period_list_new[i].fixed_delivery_obj = fixed_delivery_new[i-1]
        g_solution_period_list_new[i].tran_scheduled_obj = scheduled_cost_new[i-1]
        g_solution_period_list_new[i].fixed_scheduled_obj = fixed_scheduled_new[i-1]
        g_solution_period_list_new[i].tran_freight_obj = saving_cost_new[i-1]
        g_solution_period_list_new[i].fixed_freight_obj = saving_fixed_cost_new[i-1] 

    return() 
def createRandomDestory():
    reomve_list = []  
    for i in range(1,g_number_of_models):    
        reomve_list.append([])
    for i in range(1,g_number_of_models):
        rand_d_min = g_model_period_list[i].rand_d_min
        rand_d_max = g_model_period_list[i].rand_d_max
        demand_id_list = g_model_period_list[i].demand_id_list
        rand_d = random.uniform(rand_d_min,rand_d_max)       
        reomve_list[i-1] = random.sample(range(len(demand_id_list)),int(rand_d * len(demand_id_list)))
    return(reomve_list)
def createWorstDestory():
    reomve_list = []
    worst_remove_number = []    
    copy_node_id_list = []
    worstcopy_node_id_list = [] 
    worst_remove_number_sort = []
    for i in range(1,g_number_of_models):    
        reomve_list.append([])    
        worst_remove_number.append([]) 
        worstcopy_node_id_list.append([])
        worst_remove_number_sort.append([])
    for i in range(1,g_number_of_models):
        mid_node_id_list = g_model_period_list[i].demand_id_list
        for node_id in mid_node_id_list:
           copy_node_id_list = copy.deepcopy(mid_node_id_list)
           copy_node_id_list.remove(node_id)
           worstcopy_node_id_list[i-1].append(copy_node_id_list)
           copy_node_id_list = []
    for i in range(1,g_number_of_models):
        demand_id_list = g_model_period_list[i].demand_id_list
        worst_d_max = g_model_period_list[i].worst_d_max
        worst_d_min = g_model_period_list[i].worst_d_min              
        for j in range(len(worstcopy_node_id_list[i-1])):            
            g_solution_period_list[i].node_id_list = worstcopy_node_id_list[i-1][j]                        
            g_generation_initial_pickup_solution()
            g_generation_calObj()             
            worst_remove_number[i-1].append(g_solution_period_list[i].stage_obj - stage_total_cost[i-1])      
        g_solution_period_list[i].node_id_list = demand_id_list
        worst_remove_number_sort[i-1] = sorted(range(len(worst_remove_number[i-1])), key=lambda k: worst_remove_number[i-1][k], reverse = True)                    
        worst_d = random.randint(worst_d_min,worst_d_max)       
        reomve_list[i-1] = worst_remove_number_sort[i-1][:worst_d]    
    return (reomve_list) 

def createShawDestory(): 
    reomve_list = []    
    demand_node_number = []
    demand_node_distance = []
    demand_node_time_f = []   
    shaw_node_r_sort = []
    shaw_remove_number_sort = []    
    for i in range(1,g_number_of_models):    
        reomve_list.append([])
        demand_node_number.append([])
        demand_node_distance.append([])
        demand_node_time_f.append([])      
        shaw_node_r_sort.append([])
        shaw_remove_number_sort.append([])         
    for i in range(1,g_number_of_models):
        pickup_distance_matrix = g_model_period_list[i].pickup_distance_matrix
        pickup_depot= g_model_period_list[i].pickup_depot
        shaw_distance_index = g_model_period_list[i].shaw_distance_index 
        shaw_time_index = g_model_period_list[i].shaw_time_index
        shaw_demand_index = g_model_period_list[i].shaw_demand_index
        removal_ratio = g_model_period_list[i].removal_ratio
        demand_node_dict = g_model_period_list[i].demand_dict
        demand_node_id_list = g_model_period_list[i].demand_id_list                         
        random_index = random.randrange(len(demand_node_id_list))
        shaw_node = demand_node_id_list[random_index]
        time_depot_first = math.ceil(pickup_distance_matrix[shaw_node,pickup_depot[0]]/1)
        shaw_node_demand = sum(demand_node_dict[shaw_node])        
        for node_id in demand_node_id_list:
            if node_id != shaw_node:                
                distance = math.ceil(pickup_distance_matrix[shaw_node,node_id]/1)
                demand_node_distance[i-1].append(distance)
            if node_id == shaw_node:
                distance = 0
                demand_node_distance[i-1].append(distance)                
        for node_id in demand_node_id_list:
            if node_id != shaw_node:            
                time_first = abs(math.ceil(pickup_distance_matrix[node_id,pickup_depot[0]]/1) - time_depot_first)          
                demand_node_time_f[i-1].append(time_first)
            if node_id == shaw_node:
                time_first = 0           
                demand_node_time_f[i-1].append(time_first)             
        for node_id in demand_node_id_list:
            if node_id != shaw_node:  
                demand_node_number[i-1].append(abs(sum(demand_node_dict[node_id]) - shaw_node_demand))
            if node_id == shaw_node:
                demand_node_number[i-1].append(0)                
        shaw_node_r_sort[i-1] = list(map(lambda x,y,z: shaw_distance_index*x + shaw_time_index*y + shaw_demand_index*z, demand_node_distance[i-1], demand_node_time_f[i-1],demand_node_number[i-1]))
        shaw_remove_number_sort[i-1] = sorted(range(len(shaw_node_r_sort[i-1])), key=lambda k: shaw_node_r_sort[i-1][k], reverse = False)                          
        shaw_d = math.ceil(removal_ratio * len(demand_node_id_list)) 
        reomve_list[i-1] = shaw_remove_number_sort[i-1][:shaw_d]    
    return(reomve_list)  
def createTimeDestory():
    reomve_list = []
    demand_time = []
    demand_time_sort = []
    demand_time_route = []        
    time_node_r_sort = []            
    for i in range(1,g_number_of_models):    
        reomve_list.append([])
        demand_time.append([])
        demand_time_sort.append([])
        demand_time_route.append([])        
        time_node_r_sort.append([])
    for i in range(1,g_number_of_models): 
        demand_node_id_list = g_model_period_list[i].demand_id_list
        remained_time = g_model_period_list[i].maximum_pickup_time
        removal_route = g_model_period_list[i].removal_route
        pickup_times = total_pickup_times[i-1]
        pickup_routes = total_pickup_routes[i-1]        
        for j in range(len(pickup_times)):
            if pickup_times[j] <= remained_time:                
                demand_time[i-1].append(remained_time - pickup_times[j])
            if pickup_times[j] > remained_time: 
                demand_time[i-1].append(0)                
        demand_time_sort[i-1] = sorted(range(len(demand_time[i-1])), key=lambda k: demand_time[i-1][k], reverse = True)                             
        demand_time_sort[i-1] = demand_time_sort[i-1][:removal_route]
        for index in demand_time_sort[i-1]:
            demand_time_route[i-1].append(pickup_routes[index])            
        for route in demand_time_route[i-1]:
            time_node_r_sort[i-1] += route[1:-1]        
        for k in time_node_r_sort[i-1]:
            reomve_list[i-1].append(demand_node_id_list.index(k))                                    
    return(reomve_list)      
def createGreedyRepair():

    unassigned_nodes_id = []
    assigned_nodes_id = []
    for i in range(1,g_number_of_models):    
        unassigned_nodes_id.append([])
        assigned_nodes_id.append([])    
    #remove node from current solution    
    for i in range(1,g_number_of_models):
        demand_id_list = g_model_period_list[i].demand_id_list
        gre_node_id_list = g_solution_period_list[i].node_id_list
        for j in range(len(demand_id_list)):
            if j in reomve_list[i-1]:
                unassigned_nodes_id[i-1].append(gre_node_id_list[j])
            else:
                assigned_nodes_id[i-1].append(gre_node_id_list[j])        
        #insert
        best_insert_node_id = None
        best_insert_index = None
        best_insert_cost = float('inf')
        #calobj
        g_solution_period_list[i].node_id_list = assigned_nodes_id[i-1]
        g_generation_initial_pickup_solution()
        g_generation_calObj()        
        g_solution_period_list[i].node_id_list = demand_id_list
        for node_id in unassigned_nodes_id[i-1]:
            for k in range(len(assigned_nodes_id[i-1])):            
                mid_assigned_nodes_id = copy.deepcopy(assigned_nodes_id[i-1])
                mid_assigned_nodes_id.insert(k, node_id)
                g_solution_period_list_new[i].node_id_list = mid_assigned_nodes_id
                g_generation_initial_pickup_solution_new()
                g_generation_calObj_new()
                deta_f = g_solution_period_list_new[i].stage_obj - stage_total_cost_new[i-1]
                if deta_f < best_insert_cost:                        
                    best_insert_index = k
                    best_insert_node_id = node_id
                    best_insert_cost = deta_f           
            assigned_nodes_id[i-1].insert(best_insert_index,best_insert_node_id)
            best_insert_node_id = None
            best_insert_index = None
            best_insert_cost = float('inf') 
        g_solution_period_list_new[i].node_id_list = demand_id_list                
#    #new_solution                 
    for i in range(1,g_number_of_models):
        g_solution_period_list_new[i].node_id_list = copy.deepcopy(assigned_nodes_id[i-1])                                                          
    g_generation_initial_pickup_solution_new()
    pickup_demand_connect()
    pickup_scheduled_connect()
    g_generation_initial_scheduled_solution()
    g_generation_initial_delivery_solution()
    g_generation_calObj_new()                                
    new_obj = g_solution_period_list_new[1].obj    
    return (new_obj)     

def createRegretRepair():
    new_obj = 0
    unassigned_nodes_id = []
    assigned_nodes_id = []
    for i in range(1,g_number_of_models):    
        unassigned_nodes_id.append([])
        assigned_nodes_id.append([])    
    #remove node from current solution    
    for i in range(1,g_number_of_models):
        demand_id_list = g_model_period_list[i].demand_id_list
        gre_node_id_list = g_solution_period_list[i].node_id_list
        regret_n = g_model_period_list[i].regret_n
        for j in range(len(demand_id_list)):
            if j in reomve_list[i-1]:
                unassigned_nodes_id[i-1].append(gre_node_id_list[j])
            else:
                assigned_nodes_id[i-1].append(gre_node_id_list[j])        
        #insert              
        while len(unassigned_nodes_id[i-1]) > 0:            
            opt_insert_node_id = None
            opt_insert_index = None
            opt_insert_cost = -float('inf') 
            for node_id in unassigned_nodes_id[i-1]:
                n_insert_cost = np.zeros((len(assigned_nodes_id[i-1]),3))
                for k in range(len(assigned_nodes_id[i-1])):
                    mid_assigned_nodes_id = copy.deepcopy(assigned_nodes_id[i-1])
                    mid_assigned_nodes_id.insert(k,node_id)
                    g_solution_period_list_new[i].node_id_list = mid_assigned_nodes_id
                    g_generation_initial_pickup_solution_new()
                    g_generation_calObj_new()                
                    n_insert_cost[k,0] = node_id
                    n_insert_cost[k,1] = k
                    n_insert_cost[k,2] = stage_total_cost_new[i-1]                    
                n_insert_cost = n_insert_cost[n_insert_cost[:, 2].argsort()]                
                deta_f = 0
                for z in range(1,regret_n):
                    deta_f = deta_f + n_insert_cost[z,2] - n_insert_cost[0,2]
                if deta_f > opt_insert_cost:
                    opt_insert_node_id = int(n_insert_cost[0,0])
                    opt_insert_index = int(n_insert_cost[0,1])
                    opt_insert_cost = deta_f
            assigned_nodes_id[i-1].insert(opt_insert_index,opt_insert_node_id)
            unassigned_nodes_id[i-1].remove(opt_insert_node_id)
        g_solution_period_list_new[i].node_id_list = demand_id_list       
    #new_solution                 
    for i in range(1,g_number_of_models):
        g_solution_period_list_new[i].node_id_list = copy.deepcopy(assigned_nodes_id[i-1])                                                          
    g_generation_initial_pickup_solution_new()
    pickup_demand_connect()
    pickup_scheduled_connect()
    g_generation_initial_scheduled_solution()
    g_generation_initial_delivery_solution()
    g_generation_calObj_new() 
    new_obj = g_solution_period_list_new[1].obj    
    return (new_obj) 

def selectDestoryRepair():    
    d_weight = g_model_period_list[1].d_weight
    d_cumsumprob = (d_weight/sum(d_weight)).cumsum()
    d_cumsumprob -= np.random.rand()
    destory_id = list(d_cumsumprob > 0).index(True)

    r_weight = g_model_period_list[1].r_weight
    r_cumsumprob = (r_weight/sum(r_weight)).cumsum()
    r_cumsumprob -= np.random.rand()   
    repair_id = list(r_cumsumprob > 0).index(True)
    return destory_id,repair_id                
def doDestory():
    if destory_id == 0:
        reomve_list = createRandomDestory() 
    if destory_id == 1:
        reomve_list = createWorstDestory()            
    if destory_id == 2:
        reomve_list = createShawDestory()            
    if destory_id == 3:
        reomve_list = createTimeDestory()
    return (reomve_list)            
def doRepair():    
    if repair_id == 0:
        new_obj = createGreedyRepair()
    if repair_id == 1:
        new_obj = createRegretRepair()
    return new_obj
def resetScore():
    g_model_period_list[1].d_select = np.zeros(4)
    g_model_period_list[1].d_score  = np.zeros(4)  
    g_model_period_list[1].r_select = np.zeros(2)
    g_model_period_list[1].r_score  = np.zeros(2)    
def updateWeight():    
    for i in range(g_model_period_list[1].d_weight.shape[0]):
        if g_model_period_list[1].d_select[i] > 0:
            g_model_period_list[1].d_weight[i] = g_model_period_list[1].d_weight[i] * (1 - g_model_period_list[1].rho) + g_model_period_list[1].rho * g_model_period_list[1].d_score[i]/g_model_period_list[1].d_select[i]
        else:
            g_model_period_list[1].d_weight[i] = g_model_period_list[1].d_weight[i]
    for i in range(g_model_period_list[1].r_weight.shape[0]):
        if g_model_period_list[1].r_select[i] > 0:
            g_model_period_list[1].r_weight[i] = g_model_period_list[1].r_weight[i] * (1 - g_model_period_list[1].rho) + g_model_period_list[1].rho * g_model_period_list[1].r_score[i]/g_model_period_list[1].r_select[i]
        else:
            g_model_period_list[1].r_weight[i] = g_model_period_list[1].r_weight[i]
    g_model_period_list[1].d_history_select += g_model_period_list[1].d_select
    g_model_period_list[1].d_history_score += g_model_period_list[1].d_score
    g_model_period_list[1].r_history_select += g_model_period_list[1].r_select
    g_model_period_list[1].r_history_score += g_model_period_list[1].r_score
                                                                                     
def g_write_run_ALNS_result():    

    global g_period_demand_list,g_period_delivery_list
    stage_num_pickup_vehicles = []
    stage_num_delivery_vehicles = []    
    stage_num_scheduled_vehicles = []
    stage_num_freight_vehicles = []    

    final_obj = history_best_obj[-1]
    index = history_best_obj.index(final_obj)    
    workbook = openpyxl.Workbook()
    sheet = workbook.active
    sheet.title = 'output_ALNS_results'    
    sheet['A1'] = 'period'
    sheet['B1'] = 'demand_node_number'
    sheet['C1'] = 'stage_demand_number_of_commounity'    
    sheet['D1'] = 'stage_obj'
    sheet['E1'] = 'tran_pickup_obj'
    sheet['F1'] = 'fixed_pickup_obj' 
    sheet['G1'] = 'tran_delivery_obj'
    sheet['H1'] = 'fixed_delivery_obj' 
    sheet['I1'] = 'tran_scheduled_obj'
    sheet['J1'] = 'fixed_scheduled_obj'    
    for p in range(1, g_number_of_models):
        row = p + 1
        stage_demand_number_of_commounity = ";".join(str (number) for number in each_stage_destination_total_number[p-1])
        sheet.cell(row = row, column = 1, value = p)
        sheet.cell(row = row, column = 2, value = stage_demand_total_number[p-1])
        sheet.cell(row = row, column = 3, value = stage_demand_number_of_commounity)
        sheet.cell(row = row, column = 4, value = stage_obj[index][p-1])
        sheet.cell(row = row, column = 5, value = tran_pickup_obj[index][p-1])
        sheet.cell(row = row, column = 6, value = fixed_pickup_obj[index][p-1])
        sheet.cell(row = row, column = 7, value = tran_delivery_obj[index][p-1])
        sheet.cell(row = row, column = 8, value = fixed_delivery_obj[index][p-1])
        sheet.cell(row = row, column = 9, value = tran_scheduled_obj[index][p-1])
        sheet.cell(row = row, column = 10, value = fixed_scheduled_obj[index][p-1])
    sheet['K1'] = 'best_obj'         
    sheet['K2'] = history_best_obj[-1]
    sheet['K3'] = 'computing_time_ALNS'
    sheet['K4'] = computing_time_ALNS
    sheet['K5'] = 'remove_insert_list'
    remove_insert_list_sequence = ";".join(str (l) for l in remove_insert_list)
    sheet['K6'] = remove_insert_list_sequence
    sheet['K7'] = 'stage_destination_total_number'
    stage_destination_total_number_sequence = ";".join(str (total_number) for total_number in stage_destination_total_number)    
    sheet['K8'] = stage_destination_total_number_sequence     
    sheet['K9'] = 'num_pickup_vehicles'
    sheet['K11'] = 'num_delivery_vehicles'    
    sheet['K13'] = 'num_scheduled_vehicles'
    sheet['K15'] = 'num_freight_vehicles' 
    for i in range(1, g_number_of_models):
        stage_num_pickup_vehicles.append(int(fixed_pickup_obj[index][i-1]/fixed_logistics_vehicle_cost))
        stage_num_delivery_vehicles.append(int(fixed_delivery_obj[index][i-1]/fixed_logistics_vehicle_cost))   
        stage_num_scheduled_vehicles.append(int(fixed_scheduled_obj[index][i-1]/fixed_scheduled_freight_cost))
        stage_num_freight_vehicles.append(int(fixed_freight_obj[index][i-1]/fixed_scheduled_freight_cost))
    stage_num_pickup_vehicles_sequence = ";".join(str (vehicle) for vehicle in stage_num_pickup_vehicles)    
    stage_num_delivery_vehicles_sequence = ";".join(str (vehicle) for vehicle in stage_num_delivery_vehicles)    
    stage_num_scheduled_vehicles_sequence = ";".join(str (vehicle) for vehicle in stage_num_scheduled_vehicles)    
    stage_num_freight_vehicles_sequence = ";".join(str (vehicle) for vehicle in stage_num_freight_vehicles)    
    sheet['K10'] = stage_num_pickup_vehicles_sequence
    sheet['K12'] = stage_num_delivery_vehicles_sequence    
    sheet['K14'] = stage_num_scheduled_vehicles_sequence
    sheet['K16'] = stage_num_freight_vehicles_sequence
    sheet['K17'] = 'penalty_cost'
    sheet['K18'] = penalty_cost    
    sheet['K19'] = 'demand_pickup_vehicles_stage'
    demand_pickup_vehicles_stage_sequence = ";".join(str (l) for l in demand_pickup_vehicles_stage)
    sheet['K20'] = demand_pickup_vehicles_stage_sequence    
    workbook.save('output_ALNS_results.xlsx')
                          
    return() 
    
if __name__=='__main__':
            
    global history_best_obj,computing_time_ALNS
    global stage_obj,pickup_obj,freight_obj,scheduled_obj,delivery_obj
    global pickup_routes_fin,pickup_time_fin,scheduled_routes_fin,scheduled_time_fin,delivery_routes_fin,delivery_time_fin    
    global remove_insert_list
    global tran_pickup_obj,fixed_pickup_obj,tran_delivery_obj,fixed_delivery_obj,tran_scheduled_obj,fixed_scheduled_obj,tran_freight_obj,fixed_freight_obj
        
    #Ran-Gre,Ran-Reg,Wor-Gre,Wor-Reg,Sha-Gre,Sha-Reg,Tim-Gre,Tim-Reg
    remove_insert_list = [0] * 8
    print('Reading data......') 
    g_read_input_data()
    g_generate_in_out_going_link()
    g_generate_all_distance()
    g_generate_period_demand()
    g_generation_initial_model_data()
    g_generation_initial_node_list()
    
    #Sovle_the_model_by_ALNS
    start_ALNS = time.time()    
    history_best_obj = []
    stage_obj = []    
    pickup_obj = []
    freight_obj = []
    scheduled_obj = []
    delivery_obj = []
    pickup_routes_fin = []
    pickup_time_fin = []
    scheduled_routes_fin = []
    scheduled_time_fin = []
    delivery_routes_fin = []
    delivery_time_fin = []     
    tran_pickup_obj = []
    fixed_pickup_obj = []
    tran_delivery_obj = []
    fixed_delivery_obj = []    
    tran_scheduled_obj = []
    fixed_scheduled_obj = []
    tran_freight_obj = []
    fixed_freight_obj = []               
    for i in range(0,epochs*pu+1):
        stage_obj.append([])
        pickup_obj.append([])
        freight_obj.append([])        
        scheduled_obj.append([])
        delivery_obj.append([])  
        pickup_routes_fin.append([])
        pickup_time_fin.append([])        
        scheduled_routes_fin.append([])
        scheduled_time_fin.append([])
        delivery_routes_fin.append([])
        delivery_time_fin.append([])
        tran_pickup_obj.append([])
        fixed_pickup_obj.append([])
        tran_delivery_obj.append([])
        fixed_delivery_obj.append([])    
        tran_scheduled_obj.append([])
        fixed_scheduled_obj.append([])
        tran_freight_obj.append([])
        fixed_freight_obj.append([])            
    print('Generation initial solution...')    
    #initial_solution    
    g_generation_initial_solution()                    
    g_generation_initial_pickup_solution()
    pickup_demand_connect()
    pickup_scheduled_connect()
    g_generation_initial_scheduled_solution()
    g_generation_initial_delivery_solution()
    g_generation_calObj() 
    for i in range(1,g_number_of_models):
        g_solution_period_list[i].obj = total_cost
        g_solution_period_list[i].stage_obj = stage_total_cost[i-1]        
        g_solution_period_list[i].pickup_obj = stage_total_pickup_cost[i-1]
        g_solution_period_list[i].freight_obj = stage_total_saving_cost[i-1]
        g_solution_period_list[i].scheduled_obj = stage_total_scheduled_cost[i-1]
        g_solution_period_list[i].delivery_obj = stage_total_delivery_cost[i-1]                
        g_solution_period_list[i].pickup_routes = total_pickup_routes[i-1]
        g_solution_period_list[i].pickup_time = total_pickup_times[i-1]
        g_solution_period_list[i].scheduled_routes = total_scheduled_routes[i-1]
        g_solution_period_list[i].scheduled_time = total_scheduled_times[i-1]
        g_solution_period_list[i].delivery_routes = total_delivery_routes[i-1]
        g_solution_period_list[i].delivery_time = total_delivery_times[i-1]  
        g_solution_period_list[i].tran_pickup_obj = pickup_cost[i-1]
        g_solution_period_list[i].fixed_pickup_obj = fixed_pickup[i-1]                
        g_solution_period_list[i].tran_delivery_obj = delivery_cost[i-1]
        g_solution_period_list[i].fixed_delivery_obj = fixed_delivery[i-1]
        g_solution_period_list[i].tran_scheduled_obj = scheduled_cost[i-1]
        g_solution_period_list[i].fixed_scheduled_obj = fixed_scheduled[i-1]
        g_solution_period_list[i].tran_freight_obj = saving_cost[i-1]
        g_solution_period_list[i].fixed_freight_obj = saving_fixed_cost[i-1]                                              
    g_model_period_list[1].best_sol = copy.deepcopy(g_solution_period_list[1].obj)
    obj = g_solution_period_list[1].obj
    history_best_obj.append(obj)    
    for i in range(1,g_number_of_models):
        stage_obj[0].append(g_solution_period_list[i].stage_obj)        
        pickup_obj[0].append(g_solution_period_list[i].pickup_obj)
        freight_obj[0].append(g_solution_period_list[i].freight_obj)        
        scheduled_obj[0].append(g_solution_period_list[i].scheduled_obj)
        delivery_obj[0].append(g_solution_period_list[i].delivery_obj)  
        pickup_routes_fin[0].append(g_solution_period_list[i].pickup_routes)
        pickup_time_fin[0].append(g_solution_period_list[i].pickup_time)        
        scheduled_routes_fin[0].append(g_solution_period_list[i].scheduled_routes)
        scheduled_time_fin[0].append(g_solution_period_list[i].scheduled_time)
        delivery_routes_fin[0].append(g_solution_period_list[i].delivery_routes)
        delivery_time_fin[0].append(g_solution_period_list[i].delivery_time) 
        tran_pickup_obj[0].append(g_solution_period_list[i].tran_pickup_obj) 
        fixed_pickup_obj[0].append(g_solution_period_list[i].fixed_pickup_obj) 
        tran_delivery_obj[0].append(g_solution_period_list[i].tran_delivery_obj) 
        fixed_delivery_obj[0].append(g_solution_period_list[i].fixed_delivery_obj)     
        tran_scheduled_obj[0].append(g_solution_period_list[i].tran_scheduled_obj) 
        fixed_scheduled_obj[0].append(g_solution_period_list[i].fixed_scheduled_obj) 
        tran_freight_obj[0].append(g_solution_period_list[i].tran_freight_obj) 
        fixed_freight_obj[0].append(g_solution_period_list[i].fixed_freight_obj)          
    for ep in range(epochs):
        T = obj * 0.2
        resetScore()
        for k in range(pu):
            destory_id,repair_id = selectDestoryRepair()
            if destory_id == 0 and repair_id == 0:
                remove_insert_list[0] += 1
            if destory_id == 0 and repair_id == 1:
                remove_insert_list[1] += 1            
            if destory_id == 1 and repair_id == 0:
                remove_insert_list[2] += 1             
            if destory_id == 1 and repair_id == 1:
                remove_insert_list[3] += 1             
            if destory_id == 2 and repair_id == 0:
                remove_insert_list[4] += 1
            if destory_id == 2 and repair_id == 1:
                remove_insert_list[5] += 1            
            if destory_id == 3 and repair_id == 0:
                remove_insert_list[6] += 1             
            if destory_id == 3 and repair_id == 1:
                remove_insert_list[7] += 1                                                 
            g_model_period_list[1].d_select[destory_id] += 1
            g_model_period_list[1].r_select[repair_id] += 1 
            reomve_list = doDestory()
            new_obj = doRepair()
            new_a = random.random()
            if abs((new_obj - obj)/obj) >= 0.1:
                r1 = g_model_period_list[1].r1[2]
                r2 = g_model_period_list[1].r2[2]
                r3 = g_model_period_list[1].r3[2]                
            elif abs((new_obj - obj)/obj) >= 0.01:
                r1 = g_model_period_list[1].r1[1]
                r2 = g_model_period_list[1].r2[1]
                r3 = g_model_period_list[1].r3[1]                 
            elif abs((new_obj - obj)/obj) < 0.01:
                r1 = g_model_period_list[1].r1[0]
                r2 = g_model_period_list[1].r2[0]
                r3 = g_model_period_list[1].r3[0]
            if new_obj < obj:
                obj = copy.deepcopy(new_obj)
                if new_obj < g_model_period_list[1].best_sol:
                    g_model_period_list[1].best_sol = copy.deepcopy(new_obj)
                    g_model_period_list[1].d_score[destory_id] += r1
                    g_model_period_list[1].r_score[repair_id] += r1
                else:
                    g_model_period_list[1].d_score[destory_id] += r2
                    g_model_period_list[1].r_score[repair_id] += r2
            elif new_a < math.exp(-(new_obj - obj)/T):
                obj = copy.deepcopy(new_obj)
                g_model_period_list[1].d_score[destory_id] += r3
                g_model_period_list[1].r_score[repair_id] += r3            
            T = T * math.pow(phi,ep)        
            print("%s/%s:%s/%s， best obj: %s" % (ep,epochs,k,pu, g_model_period_list[1].best_sol))
            history_best_obj.append(g_model_period_list[1].best_sol)
            for i in range(1,g_number_of_models):
                stage_obj[ep*pu+k+1].append(g_solution_period_list_new[i].stage_obj)        
                pickup_obj[ep*pu+k+1].append(g_solution_period_list_new[i].pickup_obj)
                freight_obj[ep*pu+k+1].append(g_solution_period_list_new[i].freight_obj)        
                scheduled_obj[ep*pu+k+1].append(g_solution_period_list_new[i].scheduled_obj)
                delivery_obj[ep*pu+k+1].append(g_solution_period_list_new[i].delivery_obj)  
                pickup_routes_fin[ep*pu+k+1].append(g_solution_period_list_new[i].pickup_routes)
                pickup_time_fin[ep*pu+k+1].append(g_solution_period_list_new[i].pickup_time)        
                scheduled_routes_fin[ep*pu+k+1].append(g_solution_period_list_new[i].scheduled_routes)
                scheduled_time_fin[ep*pu+k+1].append(g_solution_period_list_new[i].scheduled_time)
                delivery_routes_fin[ep*pu+k+1].append(g_solution_period_list_new[i].delivery_routes)
                delivery_time_fin[ep*pu+k+1].append(g_solution_period_list_new[i].delivery_time)                 
                tran_pickup_obj[ep*pu+k+1].append(g_solution_period_list_new[i].tran_pickup_obj) 
                fixed_pickup_obj[ep*pu+k+1].append(g_solution_period_list_new[i].fixed_pickup_obj) 
                tran_delivery_obj[ep*pu+k+1].append(g_solution_period_list_new[i].tran_delivery_obj) 
                fixed_delivery_obj[ep*pu+k+1].append(g_solution_period_list_new[i].fixed_delivery_obj)     
                tran_scheduled_obj[ep*pu+k+1].append(g_solution_period_list_new[i].tran_scheduled_obj) 
                fixed_scheduled_obj[ep*pu+k+1].append(g_solution_period_list_new[i].fixed_scheduled_obj) 
                tran_freight_obj[ep*pu+k+1].append(g_solution_period_list_new[i].tran_freight_obj) 
                fixed_freight_obj[ep*pu+k+1].append(g_solution_period_list_new[i].fixed_freight_obj)                                 
        updateWeight()                            
    end_ALNS = time.time()
    computing_time_ALNS = end_ALNS - start_ALNS
    print(computing_time_ALNS)    
    # output data
    scheduled_vehicle_cap_output = []
    for i in range(1,g_number_of_models):
        scheduled_vehicle_cap_output.append(g_model_period_list[i].scheduled_vehicle_cap)
    g_write_run_ALNS_result()
      